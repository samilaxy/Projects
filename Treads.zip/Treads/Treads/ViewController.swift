    //
    //  ViewController.swift
    //  Treads
    //
    //  Created by Noye Samuel on 23/01/2023.
    //

import UIKit
import Nuke

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
            // Do any additional setup after loading the view.
        var thread: Thread = Thread()
        
        var dispatchQueue = DispatchQueue(label: "serial", attributes: .concurrent)
        
        DispatchQueue.global(qos: .background)
        var imgCount = 10
        
        /*
         1.  Array count is 10
         2.  countdown of completion
         3.
         */
        var imgs = ["https://i.picsum.photos/id/478/200/300.jpg?hmac=9XTsWr649TEW4EJf8V09OflQrYWLvD63zeYkUNJ8Aq4", "https://i.picsum.photos/id/237/200/200.jpg?hmac=zHUGikXUDyLCCmvyww1izLK3R3k8oRYBRiTizZEdyfI", "https://i.picsum.photos/id/866/200/300.jpg?hmac=rcadCENKh4rD6MAp6V_ma-AyWv641M4iiOpe1RyFHeI", "https://i.picsum.photos/id/881/200/300.jpg?grayscale&hmac=Dcu6Uox2IJi1KfTR5HgW5XBJfzppS7uTgtI0Gh1QjKk", "https://i.picsum.photos/id/306/200/300.jpg?blur=5&hmac=8ExpGKP5fttp7T2frCjUKKDCwUGwWpFSgZeG6HfalfE"]
        
        
    }
    
    func fetchImgs(img: String){
     
        
            // The image to dowload
        let remoteImageURL = URL(string: img)!
        
        Nuke.
    
    }
    
    
}

